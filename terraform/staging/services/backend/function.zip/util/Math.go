package util

func MaxInt(x, y int) int {
	if x < y {
		return y
	}
	return x
}
